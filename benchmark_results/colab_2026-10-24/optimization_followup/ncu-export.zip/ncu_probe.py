import sys,torch
from pathlib import Path
root=Path('/content/gliner-ab')
sys.path.insert(0,str(root/'torch-ext'))
import gliner_t4
label=sys.argv[1]
if label!='base':
 name='gliner_t4_'+label
 torch.ops.load_library(str(root/label/'torch-ext'/name/(name+'.so')))
 gliner_t4.ops=getattr(torch.ops,name)
def gpu_copy(v):
 if isinstance(v,torch.Tensor):return torch.empty_strided(v.size(),v.stride(),dtype=v.dtype,device='cuda').copy_(v)
 return v
a,k=torch.load(root/'attention-inputs.pt',weights_only=False)
a=[gpu_copy(v) for v in a];k={key:gpu_copy(v) for key,v in k.items()}
with torch.inference_mode():
 result=gliner_t4.attention(*a,**k)
 torch.cuda.synchronize()
assert torch.isfinite(result).all()
