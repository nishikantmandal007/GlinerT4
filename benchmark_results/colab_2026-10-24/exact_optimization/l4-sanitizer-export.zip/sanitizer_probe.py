import sys,torch
from pathlib import Path
root=Path('/content/gliner-ab')
sys.path.insert(0,str(root/'torch-ext'))
import gliner_t4
label=sys.argv[1]
symbol='gliner_t4_'+label
torch.ops.load_library(str(root/label/'torch-ext'/symbol/(symbol+'.so')))
candidate=getattr(torch.ops,symbol)
args=torch.load(root/'sanitizer-inputs.pt',weights_only=False)
args=[x.cuda() if isinstance(x,torch.Tensor) else x for x in args]
def run(a):
 with torch.inference_mode():
  expected=gliner_t4.ops.disentangled_attention(*a)
  actual=candidate.disentangled_attention(*a)
  torch.cuda.synchronize()
  assert torch.equal(expected.contiguous().view(torch.uint8),actual.contiguous().view(torch.uint8))
run(args)
a=list(args);a[7]=None;a[10]=None;run(a)
a=list(args);a[7]=torch.zeros_like(args[7]);a[10]=torch.zeros_like(args[10]);run(a)
a=list(args)
a[:3]=[torch.randn((99,2,64),device='cuda',dtype=torch.float16).permute(1,0,2) for _ in range(3)]
a[7]=None;a[10]=None;a[12]=torch.tensor([0,1,34,99],device='cuda',dtype=torch.int32);a[13]=65
run(a)
print('PROBE_BYTE_EQUAL',label,flush=True)
